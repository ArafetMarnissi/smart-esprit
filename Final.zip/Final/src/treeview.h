#include<gtk/gtk.h>
void afficher_personne(GtkWidget *liste);
void afficher_p(GtkWidget *liste);
