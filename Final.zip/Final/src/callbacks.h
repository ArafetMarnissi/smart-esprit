#include <gtk/gtk.h>


void
on_buttonDec_clicked                   (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonValider_clicked               (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_Admin_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_agent_de_foyer_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_agent_de_restaurant_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_nutritionniste_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_technicien_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_etudiant_clicked       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonAfret_clicked                 (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_treeviewAfficher_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonRetourAj_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonAjouter_clicked               (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttoncnx_clicked                   (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifierRetour_clicked        (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourmodifier1_clicked       (GtkWidget	*objet_graphique,
                                        gpointer         user_data);


void
on_buttonModifier1_clicked             (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourchercher_clicked        (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonChercher_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonRetourAT_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_treeviewAT_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretourSupprimer_clicked       (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_clicked             (GtkWidget	*objet_graphique,
                                        gpointer         user_data);

void
on_buttonverifier_exist_clicked        (GtkWidget	*objet_graphique,
                                        gpointer         user_data);
