#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "admin.h"
#include"treeview.h"

int rad,q;
void
on_buttonDec_clicked                   (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}


void
on_buttonValider_clicked               (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
char f[30];
GtkWidget *Combobox1;
GtkWidget *windowajouter;
GtkWidget *windowaffiche;
GtkWidget *windowafficher;
GtkWidget *windowaffichet;
GtkWidget *windowmodifier;
GtkWidget *windowsupprimer;
GtkWidget *windowchercher;
GtkWidget *eff;
GtkWidget *treeviewutil;



Combobox1=lookup_widget(objet_graphique,"comboboxAdmin");

strcpy(f,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));


if(strcmp(f,"Ajouter")==0)
{
windowajouter=create_windowAjouter ();
gtk_widget_show (windowajouter);

eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}

if(strcmp(f,"Afficher")==0)
{
afficher(rad);

windowafficher=lookup_widget(objet_graphique,"windowAfficher");
windowafficher=create_windowAfficher();
gtk_widget_show (windowafficher);
treeviewutil=lookup_widget(windowafficher,"treeviewAfficher");
afficher_p(GTK_TREE_VIEW (treeviewutil));
eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}

if(strcmp(f,"Afficher tout")==0)
{
windowaffichet=lookup_widget(objet_graphique,"windowAffichert");
windowaffichet=create_windowAffichert();
gtk_widget_show (windowaffichet);
treeviewutil=lookup_widget(windowaffichet,"treeviewAT");
afficher_personne(GTK_TREE_VIEW (treeviewutil));
eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}

if(strcmp(f,"Modifier")==0)
{
windowmodifier=create_windowModifier();
gtk_widget_show (windowmodifier);
eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}

if(strcmp(f,"Supprimer")==0)
{
windowsupprimer=create_windowSupprimer();
gtk_widget_show (windowsupprimer);
eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}

if(strcmp(f,"Chercher")==0)
{
windowchercher=create_windowChercher();
gtk_widget_show (windowchercher);
eff=lookup_widget(objet_graphique,"windowAdmin");
gtk_widget_hide(eff);
}
}


void
on_Admin_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
rad=0;
}


void
on_radiobutton2_agent_de_foyer_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
rad=1;
}


void
on_radiobutton3_agent_de_restaurant_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
rad=2;
}


void
on_radiobutton4_nutritionniste_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
rad=3;
}


void
on_radiobutton5_technicien_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
rad=4;
}


void
on_radiobutton6_etudiant_clicked       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
rad=5;
}


void
on_buttonAfret_clicked                 (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowAdmin();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowAfficher");
gtk_widget_hide(eff);
}


void
on_treeviewAfficher_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* role;
	gchar* nom;
	gchar* prenom;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* username;
	gchar* password;
	gchar* cin;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get (GTK_TREE_MODEL(model),&iter,0,&role,1,&nom,2,&prenom,3,&jour,4,&mois,5,&annee,6,&username,7,&password,8,&cin,-1);
		afficher_p(treeview);

	}
}


void
on_buttonRetourAj_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowAdmin();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowAjouter");
gtk_widget_hide(eff);
}


void
on_buttonAjouter_clicked               (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
int i,k;
utilisateur u, user[1000];
char RE[50];
int n=0;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *username;
GtkWidget *password;
GtkWidget *j;
GtkWidget *m;
GtkWidget *a;
GtkWidget *cin;
GtkWidget *output ;
int z=0;
n=importer(user,n);


nom=lookup_widget (objet_graphique,"entryNom");
prenom=lookup_widget (objet_graphique,"entryPrenom");
username=lookup_widget (objet_graphique,"entryUsername");
password=lookup_widget (objet_graphique,"entryPassword");
cin=lookup_widget (objet_graphique,"entryCIN");
j=lookup_widget(objet_graphique,"spinbuttonJour");
m=lookup_widget(objet_graphique,"spinbuttonMois");
a=lookup_widget(objet_graphique,"spinbuttonAnnee");


u.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
u.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
u.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));
strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(u.username, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(u.password, gtk_entry_get_text(GTK_ENTRY(password)));
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));


if(rad==0)
strcpy(u.role,"Admin");
if(rad==1)
strcpy(u.role,"Agent_de_foyer");
if(rad==2)
strcpy(u.role,"Agent_de_restaurant");
if(rad==3)
strcpy(u.role,"Nutritionniste");
if(rad==4)
strcpy(u.role,"Technicien");
if(rad==5)
strcpy(u.role,"Etudiant");

z=chercher_user(u.cin);


if(z==1)
{output=lookup_widget(objet_graphique,"labelAjouterresult");
strcpy(RE," utilisateur deja existant");
gtk_label_set_text(GTK_LABEL(output),RE);
}
else
{
n=ajouter_user(user,u ,n);
sauvegarder(user,n);
output=lookup_widget(objet_graphique,"labelAjouterresult");
strcpy(RE,"utilisateur ajouté avec succés");
gtk_label_set_text(GTK_LABEL(output),RE);

}
}


void
on_buttoncnx_clicked                   (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
int x;
GtkWidget *eff;
GtkWidget *windowadmin;
GtkWidget *windowagent_de_restaurant;
GtkWidget *windowagent_de_foyer;
GtkWidget *windownutritionniste;
GtkWidget *windowtechnicien;
GtkWidget *windowetudiant;
char a[50];
char p[50];
GtkWidget *user;
GtkWidget *password;

user=lookup_widget(objet_graphique,"entryAuuser");
password=lookup_widget(objet_graphique,"entryAumdp");
strcpy(a, gtk_entry_get_text(GTK_ENTRY(user)));
strcpy(p, gtk_entry_get_text(GTK_ENTRY(password)));

x=connexion(a,p);

if(x==0)
{
windowadmin=create_windowAdmin();
gtk_widget_show (windowadmin);
eff=lookup_widget(objet_graphique,"windowAuth");
gtk_widget_hide(eff);
}

/*if(x==1)
{
windowagent_de_foyer=create_();
gtk_widget_show (windowagent_de_foyer);
eff=lookup_widget(objet_graphique,"windowAuth");
gtk_widget_hide(eff);
}

if(x==2)
{
windowagent_de_restaurant=create_();
gtk_widget_show (windowagent_de_restaurant);
eff=lookup_widget(objet_graphique,"windowAuth");
gtk_widget_hide(eff);
}

if(x==3)
{
windownutritionniste=create_();
gtk_widget_show (windownutritionniste);
eff=lookup_widget(objet_graphique,"windowAuth");
gtk_widget_hide(eff);
}

if(x==4)
{
windowtechnicien=create_();
gtk_widget_show (windowtechnicien);
eff=lookup_widget(objet_graphique,"windowAuth");
gtk_widget_hide(eff);
}

if(x==5)
{
windowetudiant=create_();
gtk_widget_show (windowetudiant);
eff=lookup_widget(objet_graphique,"windowAuth");
gtk_widget_hide(eff);
}
*/
}


void
on_buttonmodifierRetour_clicked        (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowAdmin();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowModifier");
gtk_widget_hide(eff);
}


void
on_buttonModifier_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
int x=0;
FILE *l=NULL;
char cin[20];
char RE[50];
GtkWidget *input;
GtkWidget *output;
GtkWidget *window;
GtkWidget *eff;


input=lookup_widget(objet_graphique,"entrycinmod");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
x=chercher_user(cin);

l=fopen("testmo.txt","w+");
fprintf(l,"%s",cin);
fclose(l);

if(x==1)
{
eff=lookup_widget(objet_graphique,"windowModifier");
gtk_widget_hide(eff);
window=create_windowModifier2();
gtk_widget_show (window);
}
else
{
output=lookup_widget(objet_graphique,"labelModifier");
strcpy(RE,"utilisateur n'existe pas");
gtk_label_set_text(GTK_LABEL(output),RE);
}
}


void
on_buttonretourmodifier1_clicked       (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowModifier();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowModifier2");
gtk_widget_hide(eff);
}





void
on_buttonModifier1_clicked             (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
FILE *l=NULL;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *username;
GtkWidget *password;
GtkWidget *j;
GtkWidget *m;
GtkWidget *a;
GtkWidget *cin;
GtkWidget *combobox;
utilisateur d;
int z=0;
int x=1;
char chaine[100];
FILE *n=NULL;


nom=lookup_widget (objet_graphique,"entrymnom");
prenom=lookup_widget (objet_graphique,"entrymprenom");
username=lookup_widget (objet_graphique,"entrymuser");
password=lookup_widget (objet_graphique,"entrympassword");
cin=lookup_widget (objet_graphique,"entrymcin");
j=lookup_widget (objet_graphique,"labelmresult");
combobox=lookup_widget(objet_graphique,"comboboxmodifer");

strcpy(d.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(d.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(d.username, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(d.password, gtk_entry_get_text(GTK_ENTRY(password)));
strcpy(d.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(d.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));



if(q==0)
{
strcpy(chaine,"modification impossible (cin non verifié)");
gtk_label_set_text(GTK_LABEL(j),chaine);
}
if(q==1)
{
strcpy(chaine,"modifié avec succés");
gtk_label_set_text(GTK_LABEL(j),chaine);
modifier_user(d);
}

}


void
on_buttonretourchercher_clicked        (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowAdmin();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowChercher");
gtk_widget_hide(eff);
}


void
on_buttonChercher_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
int x=0;
FILE *f=NULL;
char cin[20];
char RE[100];
GtkWidget *input;
GtkWidget *output;

input=lookup_widget(objet_graphique,"entrycher");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
x=chercher_user(cin);
//output=lookup_widget(objet_graphique,"labelcher");

if(x==1)
{output=lookup_widget(objet_graphique,"labelcher");
strcpy(RE," utilisateur existe");
gtk_label_set_text(GTK_LABEL(output),RE);
}
else
{
output=lookup_widget(objet_graphique,"labelcher");
strcpy(RE,"utilisateur n'existe pas");
gtk_label_set_text(GTK_LABEL(output),RE);
}

}


void
on_buttonRetourAT_clicked              (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowAdmin();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowAffichert");
gtk_widget_hide(eff);
}


void
on_treeviewAT_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* role;
	gchar* nom;
	gchar* prenom;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* username;
	gchar* password;
	gchar* cin;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get (GTK_TREE_MODEL(model),&iter,0,&role,1,&nom,2,&prenom,3,&jour,4,&mois,5,&annee,6,&username,7,&password,8,&cin,-1);
		afficher_personne(treeview);

	}
}


void
on_buttonretourSupprimer_clicked       (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *eff;
GtkWidget *windowAdmin;
windowAdmin=create_windowAdmin();
gtk_widget_show (windowAdmin);
eff=lookup_widget(objet_graphique,"windowSupprimer");
gtk_widget_hide(eff);
}


void
on_buttonSupprimer_clicked             (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
int x=0;
char cin[20]="";
char RE[50];
GtkWidget *input;
GtkWidget *output;

input=lookup_widget(objet_graphique,"entrySupprimer");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
x=chercher_user(cin);


if(x==1)
{
supprimer_user(cin);
output=lookup_widget(objet_graphique,"labelSupprimer");
strcpy(RE," utilisateur supprimé avec succés");
gtk_label_set_text(GTK_LABEL(output),RE);
}
else
{
output=lookup_widget(objet_graphique,"labelSupprimer");
strcpy(RE,"utilisateur n'existe pas");
gtk_label_set_text(GTK_LABEL(output),RE);
}
}


void
on_buttonverifier_exist_clicked        (GtkWidget	*objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *m;
GtkWidget *cin;
utilisateur d;
int z=0;
int x=1;

FILE *n=NULL;
char id[20];

char mg[100];

cin=lookup_widget (objet_graphique,"entrymcin");
m=lookup_widget(objet_graphique,"labelconfirmat");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(cin)));


q=chercher_user(id);
if(q==0)
{
strcpy(mg,"cin n'existe pas (n'est pas modifiable)");
gtk_label_set_text(GTK_LABEL(m),mg);
}
else if(q==1)
{
strcpy(mg,"cin verifié");
gtk_label_set_text(GTK_LABEL(m),mg);
}
}
